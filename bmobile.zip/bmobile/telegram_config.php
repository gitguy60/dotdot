<?php
// telegram_config.php

// Telegram Bot API credentials
$botToken = "";
$chatID = "";
?>
