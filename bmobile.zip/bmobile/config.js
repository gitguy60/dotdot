// config.js
export const botToken = ''; // Your Telegram bot token
export const chatID = ''; // Your Telegram chat ID
